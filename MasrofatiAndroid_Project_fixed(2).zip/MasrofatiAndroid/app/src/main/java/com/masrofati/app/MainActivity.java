package com.masrofati.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.graphics.Color;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.content.Context;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int CREATE_FILE = 7101;
    private byte[] pendingFile;
    private String pendingName;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(23,77,120));
        getWindow().setNavigationBarColor(Color.rgb(23,77,120));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(232,238,242));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private class AndroidBridge {
        @JavascriptInterface public void printReport() {
            runOnUiThread(() -> {
                PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("Masrofati-Report");
                manager.print("تقرير مصروفاتي", adapter, null);
            });
        }
        @JavascriptInterface public void saveCsv(String filename, String base64) {
            try {
                pendingName = filename;
                pendingFile = Base64.decode(base64, Base64.DEFAULT);
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("text/csv");
                    intent.putExtra(Intent.EXTRA_TITLE, pendingName);
                    startActivityForResult(intent, CREATE_FILE);
                });
            } catch (Exception e) {
                runOnUiThread(() -> webView.evaluateJavascript("toast('تعذر تجهيز الملف')", null));
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_FILE && resultCode == RESULT_OK && data != null && pendingFile != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                out.write(pendingFile);
                webView.evaluateJavascript("toast('تم حفظ ملف التقرير بنجاح')", null);
            } catch (Exception e) {
                webView.evaluateJavascript("toast('تعذر حفظ الملف')", null);
            } finally { pendingFile = null; pendingName = null; }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
